// Visit https://api.openweathermap.org & then signup to get our API keys for free
module.exports = {
  key: "6f230731e5daf9ffdc37722008a25140",
  base: "https://api.openweathermap.org/data/2.5/",
};
